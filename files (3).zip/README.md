# Node.js and MongoDB with Docker

## Setup Instructions

1. Clone the repository:
   ```bash
   git clone <repository-url>
   cd my-node-mongo-app
   ```

2. Create a `.env` file in the root directory and add the following:
   ```plaintext
   PORT=3000
   MONGO_URI=mongodb://mongo:27017/mydatabase
   ```

3. Build and run the containers:
   ```bash
   docker-compose up --build
   ```

4. Access the app at `http://localhost:3000`.

## Useful Commands

- To stop containers: `docker-compose down`
- To rebuild containers: `docker-compose up --build`
- To clean Docker volumes: `docker volume prune`

## Notes

- Ensure Docker and Docker Compose are installed on your system.
- MongoDB data is persisted in the `mongo_data` volume.